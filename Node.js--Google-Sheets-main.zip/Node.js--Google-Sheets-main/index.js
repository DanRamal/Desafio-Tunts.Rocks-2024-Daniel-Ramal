const express = require("express");
const req = require("express/lib/request");
const { google } = require("googleapis");

const app = express();
app.use(express.json());

async function getAuthSheets() {
  const auth = new google.auth.GoogleAuth({
    keyFile: "credentials.json",
    scopes: "https://www.googleapis.com/auth/spreadsheets",
  });

  const client = await auth.getClient();

  const googleSheets = google.sheets({
    version: "v4",
    auth: client,
  });

  const spreadsheetId = "1tZI9cQ_CIhOwX8ed4AxwCTRho5Tadi5WacpR_oicTm4";

  return {
    auth,
    client,
    googleSheets,
    spreadsheetId,
  };
}

app.get("/metadata", async (req, res) => {
  const { googleSheets, auth, spreadsheetId } = await getAuthSheets();

  const metadata = await googleSheets.spreadsheets.get({
    auth,
    spreadsheetId,
  });

  res.send(metadata.data);
});

app.get("/getRows", async (req, res) => {
  const { googleSheets, auth, spreadsheetId } = await getAuthSheets();

  const getRows = await googleSheets.spreadsheets.values.get({
    auth,
    spreadsheetId,
    range: "Página1",
    valueRenderOption: "UNFORMATTED_VALUE",
    dateTimeRenderOption: "FORMATTED_STRING",
  });

  res.send(getRows.data);
});

app.post("/addRow", async (req, res) => {
  const { googleSheets, auth, spreadsheetId } = await getAuthSheets();

  const { values } = req.body;

  // Calcula a média das notas
  const media = (parseFloat(values[0]) + parseFloat(values[1]) + parseFloat(values[2])) / 3;

  // Calcula a porcentagem de faltas
  const faltas = parseFloat(values[3]) / parseFloat(values[4]);

  // Calcula a situação do aluno
  const situacao = calcularSituacao(media, faltas);

  // Preenche a nota para aprovação final (NAF) se a situação for "Exame Final"
  const naf = situacao === "Exame Final" ? calcularNAF(media) : 0;

  // Adiciona a situação e a NAF ao final da linha
  values.push(situacao, naf);

  const row = await googleSheets.spreadsheets.values.append({
    auth,
    spreadsheetId,
    range: "Página1",
    valueInputOption: "USER_ENTERED",
    resource: {
      values: [values],
    },
  });

  res.send(row.data);
});

function calcularNAF(media) {
  return Math.ceil((10 - media) * 2);
}

app.get("/getNotas", async (req, res) => {
  try {

    // Autenticar e obter acesso à planilha
    const { auth, googleSheets, spreadsheetId } = await getAuthSheets();
    const getTotalRows = await googleSheets.spreadsheets.values.get({
      auth,
      spreadsheetId,
      range: "engenharia_de_software!A:A", // Consulta a coluna A para obter todas as linhas
    });

    let totalrows = getTotalRows.data.values.length;

    console.log('total de linhas ', totalrows);

    if (totalrows != null && totalrows > 0) {
      totalrows = totalrows - 3;

      for (let index = 0; index < totalrows; index++) { 
        const getGrades = await googleSheets.spreadsheets.values.get({
          auth,
          spreadsheetId,
          range: `engenharia_de_software!D${index + 4}:F${index + 4}`, // Especifique o intervalo onde estão as notas na planilha
        });

        const grades = getGrades.data.values[0];

        console.log('grades ',grades);

        let media = ( grades[0] + grades[1] + grades[2]) / 3;



        console.log('media ',media);
      }

    }

    // Consultar a planilha para obter as notas

    // Extrair os dados da resposta
    const notas = 3;

    // Verificar se há dados
    if (notas.length) {
      res.send(notas);
    } else {
      res.status(404).send("Nenhuma nota encontrada.");
    }
  } catch (error) {
    console.error("Erro ao obter notas:", error);
    res.status(500).send("Erro ao obter notas.");
  }
});

app.post("/updateValue", async (req, res) => {
  const { googleSheets, auth, spreadsheetId } = await getAuthSheets();

  const { values } = req.body;

  const updateValue = await googleSheets.spreadsheets.values.update({
    spreadsheetId,
    range: "Página1!A2:C2",
    valueInputOption: "USER_ENTERED",
    resource: {
      values: values,
    },
  });

  res.send(updateValue.data);
});

function calcularSituacao(media, faltas) {
  if (faltas > 0.25) {
    return "Reprovado por Falta";
  } else if (media < 5) {
    return "Reprovado por Nota";
  } else if (media >= 5 && media < 7) {
    return "Exame Final";
  } else {
    return "Aprovado";
  }
}

app.listen(3001, () => console.log("Rodando na porta 3001"));
